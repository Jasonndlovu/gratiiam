package com.comp.gratiiam;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
